
	</div> 
       
</div>

</div>

<?php hook_mobile_footer(); ?>

<?php wp_footer(); ?>
 
</body>

</html>