<?php

define('WLT_DATING', true);

?>