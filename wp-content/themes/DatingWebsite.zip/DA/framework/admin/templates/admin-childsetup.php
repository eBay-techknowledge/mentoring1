<?php
/* 
* Theme: PREMIUMPRESS CORE FRAMEWORK FILE
* Url: www.premiumpress.com
* Author: Mark Fail
*
* THIS FILE WILL BE UPDATED WITH EVERY UPDATE
* IF YOU WANT TO MODIFY THIS FILE, CREATE A CHILD THEME
*
* http://codex.wordpress.org/Child_Themes
*/
if (!defined('THEME_VERSION')) {	header('HTTP/1.0 403 Forbidden'); exit; }

// LOAD IN MAIN DEFAULTS 
$core_admin_values = get_option("core_admin_values");  
  
?> 

<div class="row-fluid">

<div class="span8">

 
<!-- START ACCORDING --->
<div class="accordion style1" id="childtheme_according">
 
 
<?php hook_admin_1_tab1_subtab1(); ?>
  


</div><!-- END ACCORDING -->

<hr />
<p>no more options found for this child theme.</p>





	

</div>

<div class="span4">


 
        
</div>

</div>

</div>
 