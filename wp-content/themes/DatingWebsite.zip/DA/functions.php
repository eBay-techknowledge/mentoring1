<?php
/* =============================================================================
   DEBUG OPTIONS
   ========================================================================== */
	
	//ini_set('log_errors', 1);
	//ini_set('error_log', 'premiumpress_errorlog.txt');
	//ini_set( 'display_errors', 1 );
	//error_reporting( E_ERROR | E_WARNING | E_PARSE | E_NOTICE | E_STRICT );
	//define('SAVEQUERIES', true);
	
	//define('WLT_CUSTOMLOGINFORM', false);
	//define('WLT_DEBUG_EMAIL', true);
	//define('WLT_DEBUG_MOBILE', true);
	//define('WLT_DEMOMODE',true);
 
/* =============================================================================
   LOAD IN FRAMEWORK
   ========================================================================== */
  	
	if(defined('TEMPLATEPATH') && !defined('THEME_VERSION') ){ include("framework/_config.php"); }	

/* =============================================================================
   ADD YOUR CUSTOM CODE BELOW THIS LINE
   ========================================================================== */ 
?>